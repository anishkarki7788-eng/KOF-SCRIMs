# KOF SCRIMS ZONE 🇳🇵

A mobile-first Free Fire scrim management starter for Nepal, built with React + Vite + Supabase. Theme: black, red and gold.

## Included

- Responsive home page and scrim cards
- Scrim registration with a 12-team default capacity
- Player sign-up / sign-in and team profiles (Supabase Auth)
- Admin dashboard to create scrims, approve/reject teams, review payment status, and post results
- Auto-calculated leaderboard: placement points + kill points, sorted by total points
- eSewa / bank transfer payment reference tracking
- Demo mode so you can preview the UI before connecting a database

## Important limitations

- Demo mode stores changes only in the current browser session/state. It is not a shared online tournament database.
- Real accounts, shared registrations, and secure admin features require Supabase configuration.
- Payment tracking is manual. This starter does **not** verify real eSewa payments or process money. Official merchant onboarding, server-side verification, and provider credentials are needed for automatic payment confirmation. Never put secret keys in frontend `.env` variables.
- The leaderboard currently uses this default scoring: 1st=12, 2nd=9, 3rd=8, 4th=7, 5th=6, 6th=5, 7th=4, 8th=3, 9th=2, 10th=1, 11th–12th=0; each kill=1 point. Edit `placementPoints` in `src/App.jsx` to change it.

## Run locally

Install Node.js 20+ from https://nodejs.org/ and then in this folder run:

```bash
npm install
npm run dev
```

Open the local URL Vite prints (usually `http://localhost:5173`).

## Connect Supabase for live data and accounts

1. Create a project at https://supabase.com/.
2. In Supabase, open **SQL Editor**, create a new query, paste all of `supabase/schema.sql`, and run it.
3. In Supabase project settings, find the Project URL and anon/public key.
4. Copy `.env.example` to `.env` and fill in:

```env
VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

5. Stop and restart `npm run dev` after changing `.env`.
6. Create your player account from **Profile** in the website.
7. Promote your own account to admin in Supabase **SQL Editor**. Replace the email below with the email you registered with:

```sql
update public.profiles
set role = 'admin'
where id = (select id from auth.users where email = 'YOUR-EMAIL@example.com');
```

8. Reload the website and sign in again. The **Admin** tab should appear.
9. In Supabase **Authentication → URL Configuration**, set your local URL while testing and your deployed website URL after publishing. Configure email confirmation as you prefer.

### Security notes

- Never use the Supabase `service_role` key in frontend code. Use only the anon/public key with RLS enabled.
- Keep the SQL policies enabled. Test registration and admin actions using a separate non-admin account before inviting real teams.
- If you change the admin role manually, do not allow public users to update their own role.
- Consider adding CAPTCHA/rate limiting and a privacy notice before opening registrations to everyone.

## Publish online using Vercel

1. Create a GitHub account if needed and make a new repository named `kof-scrims-zone`.
2. Upload the project files to the repository (do not upload `.env`).
3. Go to https://vercel.com/ and import the repository.
4. Vercel normally detects Vite automatically. Build command: `npm run build`; output directory: `dist`.
5. In Vercel project **Settings → Environment Variables**, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
6. Deploy. Copy the live URL and add it to Supabase **Authentication → URL Configuration** as the Site URL and an allowed redirect URL.
7. Test sign-up, sign-in, registration, admin review, and leaderboard on your live URL.

Alternative hosting: Netlify can also deploy a Vite app using build command `npm run build` and publish directory `dist`.

## Suggested next upgrades

- Real eSewa gateway integration with server-side callbacks and payment verification
- Registration form custom fields (captain UID, WhatsApp number, team logo)
- Room ID/password release to approved teams only
- CSV exports and match-by-match points
- Anti-cheat/report and dispute workflow
- Custom domain such as `kofscrimszone.com` if available
