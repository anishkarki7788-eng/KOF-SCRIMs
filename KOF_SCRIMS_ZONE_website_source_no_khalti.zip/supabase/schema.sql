-- KOF SCRIMS ZONE database schema
-- Run this entire file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Player',
  role text not null default 'player' check (role in ('player','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.scrims (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  game text not null default 'Free Fire',
  date date,
  time text not null default '7:30 PM NPT',
  entry_fee integer not null default 0 check (entry_fee >= 0),
  prize_pool integer not null default 0 check (prize_pool >= 0),
  slots integer not null default 12 check (slots between 2 and 100),
  maps text not null default 'B / P / K / N',
  status text not null default 'open' check (status in ('open','closed')),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.teams (
  id uuid primary key default gen_random_uuid(),
  scrim_id uuid not null references public.scrims(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  team_name text not null,
  captain_ign text not null,
  players jsonb not null default '[]'::jsonb,
  registration_status text not null default 'pending' check (registration_status in ('pending','approved','rejected')),
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','rejected')),
  created_at timestamptz not null default now()
);
create unique index if not exists teams_unique_name_per_scrim on public.teams (scrim_id, lower(team_name));

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  method text not null check (method in ('eSewa','Bank transfer','Other')),
  reference text,
  amount integer not null check (amount >= 0),
  status text not null default 'pending' check (status in ('pending','paid','rejected')),
  reviewed_by uuid references auth.users(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.match_results (
  id uuid primary key default gen_random_uuid(),
  scrim_id uuid not null references public.scrims(id) on delete cascade,
  team_name text not null,
  match_no integer not null default 1 check (match_no >= 1),
  placement integer not null check (placement between 1 and 12),
  placement_points integer not null default 0 check (placement_points >= 0),
  kills integer not null default 0 check (kills >= 0),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

-- Auto-create a player profile for each newly registered auth user.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email,'@',1)))
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

alter table public.profiles enable row level security;
alter table public.scrims enable row level security;
alter table public.teams enable row level security;
alter table public.payments enable row level security;
alter table public.match_results enable row level security;

-- Profiles: public profile names/roles are readable for basic app display; only own profile can be changed.
create policy "profiles readable by signed-in users" on public.profiles for select to authenticated using (true);
create policy "profile owner updates own non-role fields" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and role = 'player');
create policy "admins manage profiles" on public.profiles for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Scrims and results are public read-only; admins manage them.
create policy "scrims public read" on public.scrims for select using (true);
create policy "admins manage scrims" on public.scrims for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "results public read" on public.match_results for select using (true);
create policy "admins manage results" on public.match_results for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Teams: owners can submit/view their teams; admins can review all.
create policy "teams visible to owner or admin" on public.teams for select to authenticated using (owner_id = auth.uid() or public.is_admin());
create policy "users register own teams" on public.teams for insert to authenticated with check (owner_id = auth.uid() and registration_status = 'pending' and payment_status = 'pending');
create policy "admins manage teams" on public.teams for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Payments: owners can view/create their own pending payment records; admins can review.
create policy "payments visible to owner or admin" on public.payments for select to authenticated using (user_id = auth.uid() or public.is_admin());
create policy "users create pending own payments" on public.payments for insert to authenticated with check (user_id = auth.uid() and status = 'pending');
create policy "admins manage payments" on public.payments for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Seed scrims only if the table is empty.
insert into public.scrims(title, date, time, entry_fee, prize_pool, slots, maps, status)
select 'KOF 7:30 PM PAID SCRIM', current_date + 1, '7:30 PM NPT', 30, 260, 12, 'B / P / K / N', 'open'
where not exists (select 1 from public.scrims);
