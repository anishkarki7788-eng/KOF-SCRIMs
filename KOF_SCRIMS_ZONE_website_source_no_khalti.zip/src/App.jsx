import React, { useEffect, useMemo, useState } from 'react';
import { supabase, isSupabaseConfigured } from './supabase';
import {
  Swords, Trophy, Users, ShieldCheck, Wallet, LogIn, LogOut, Menu, X,
  Plus, RefreshCw, Medal, ChevronRight, CircleDollarSign, ClipboardList,
  UserRound, Crown, AlertTriangle, CheckCircle2, Clock3, ExternalLink
} from 'lucide-react';

const demoScrims = [
  { id:'demo-1', title:'KOF 7:30 PM PAID SCRIM', game:'Free Fire', date:new Date(Date.now()+86400000).toISOString().slice(0,10), time:'7:30 PM NPT', entry_fee:30, prize_pool:260, slots:12, maps:'B / P / K / N', status:'open' },
  { id:'demo-2', title:'KOF 10:45 PM SCRIM', game:'Free Fire', date:new Date(Date.now()+86400000).toISOString().slice(0,10), time:'10:45 PM NPT', entry_fee:20, prize_pool:180, slots:12, maps:'B / P / K / N', status:'open' }
];
const demoTeams = [{id:'demo-team', team_name:'KOF', captain_ign:'FROST', players:['FROST'], scrim_id:'demo-1', payment_status:'paid', registration_status:'approved', created_at:new Date().toISOString()}];
const demoResults = [
  {team_name:'KOF',placement:1,kills:12,match_no:1},
  {team_name:'DEMO ESP',placement:2,kills:8,match_no:1},
  {team_name:'RIVAL ESP',placement:3,kills:6,match_no:1}
];
const placementPoints = {1:12,2:9,3:8,4:7,5:6,6:5,7:4,8:3,9:2,10:1,11:0,12:0};
const money = n => `Rs. ${Number(n || 0).toLocaleString('en-IN')}`;
const dateText = d => d ? new Date(`${d}T00:00:00`).toLocaleDateString('en-GB',{day:'2-digit',month:'short'}) : 'Date TBA';

function buildTable(results) {
  const totals = {};
  results.forEach(r => {
    const name = r.team_name || 'Unknown team';
    if (!totals[name]) totals[name] = {team_name:name, matches:0, placement_points:0, kills:0, total:0, booyahs:0};
    const t = totals[name];
    t.matches += 1;
    t.kills += Number(r.kills || 0);
    t.placement_points += Number(r.placement_points ?? placementPoints[Number(r.placement)] ?? 0);
    t.booyahs += Number(r.placement) === 1 ? 1 : 0;
    t.total = t.placement_points + t.kills;
  });
  return Object.values(totals).sort((a,b) => b.total-a.total || b.booyahs-a.booyahs || b.kills-a.kills);
}

export default function App() {
  const [tab,setTab] = useState('Home');
  const [mobileMenu,setMobileMenu] = useState(false);
  const [user,setUser] = useState(null);
  const [profile,setProfile] = useState(null);
  const [scrims,setScrims] = useState(demoScrims);
  const [teams,setTeams] = useState(demoTeams);
  const [results,setResults] = useState(demoResults);
  const [payments,setPayments] = useState([]);
  const [loading,setLoading] = useState(isSupabaseConfigured);
  const [notice,setNotice] = useState(isSupabaseConfigured ? 'Connect your Supabase project and configure an admin account to enable live shared data.' : 'Demo preview: data is stored only in this browser. Connect Supabase for real accounts and shared tournament data.');
  const [authMode,setAuthMode] = useState('signin');
  const [authEmail,setAuthEmail] = useState('');
  const [authPassword,setAuthPassword] = useState('');
  const [displayName,setDisplayName] = useState('');
  const [teamForm,setTeamForm] = useState({scrim_id:'demo-1',team_name:'',captain_ign:'',player2:'',player3:'',player4:'',payment_method:'eSewa',payment_reference:''});
  const [resultForm,setResultForm] = useState({scrim_id:'demo-1',match_no:1,team_name:'',placement:1,kills:0});
  const [scrimForm,setScrimForm] = useState({title:'KOF NEW SCRIM',date:'',time:'7:30 PM NPT',entry_fee:30,prize_pool:260,slots:12,maps:'B / P / K / N'});
  const [isAdmin,setIsAdmin] = useState(false);

  async function loadData() {
    if (!isSupabaseConfigured) { setLoading(false); return; }
    setLoading(true);
    const [s,t,r,p] = await Promise.all([
      supabase.from('scrims').select('*').order('created_at',{ascending:false}),
      supabase.from('teams').select('*').order('created_at',{ascending:true}),
      supabase.from('match_results').select('*'),
      supabase.from('payments').select('*').order('created_at',{ascending:false})
    ]);
    if (!s.error) setScrims(s.data || []);
    if (!t.error) setTeams(t.data || []);
    if (!r.error) setResults(r.data || []);
    if (!p.error) setPayments(p.data || []);
    setLoading(false);
  }

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    supabase.auth.getSession().then(({data}) => setUser(data.session?.user || null));
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_event,session) => {
      setUser(session?.user || null);
      setProfile(null);
      setIsAdmin(false);
    });
    loadData();
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!user || !isSupabaseConfigured) return;
    (async () => {
      const {data} = await supabase.from('profiles').select('*').eq('id',user.id).maybeSingle();
      setProfile(data || null);
      setIsAdmin(data?.role === 'admin');
    })();
  }, [user]);

  const standings = useMemo(() => buildTable(results), [results]);
  const nav = ['Home','Scrims','Leaderboard','Register','Payments','Profile'];
  if (isAdmin) nav.push('Admin');

  async function signIn(e) {
    e.preventDefault();
    if (!isSupabaseConfigured) return setNotice('To enable real accounts, complete the Supabase setup in README.md first.');
    const fn = authMode === 'signup' ? supabase.auth.signUp({email:authEmail,password:authPassword,options:{data:{display_name:displayName}}}) : supabase.auth.signInWithPassword({email:authEmail,password:authPassword});
    const {error} = await fn;
    setNotice(error ? error.message : authMode === 'signup' ? 'Account created. Check your email if confirmation is enabled, then sign in.' : 'Signed in successfully.');
  }
  async function signOut() {
    if (isSupabaseConfigured) await supabase.auth.signOut();
    setUser(null); setProfile(null); setIsAdmin(false); setNotice('Signed out.');
  }
  async function registerTeam(e) {
    e.preventDefault();
    const players = [teamForm.captain_ign,teamForm.player2,teamForm.player3,teamForm.player4].map(x=>x.trim()).filter(Boolean);
    if (!teamForm.team_name.trim() || !teamForm.captain_ign.trim()) return setNotice('Enter your team name and captain IGN.');
    if (!isSupabaseConfigured) {
      if (teams.some(t=>t.scrim_id===teamForm.scrim_id && t.team_name.toLowerCase()===teamForm.team_name.toLowerCase())) return setNotice('That team is already registered for this scrim.');
      const scrim = scrims.find(s=>s.id===teamForm.scrim_id);
      const count = teams.filter(t=>t.scrim_id===teamForm.scrim_id && t.registration_status!=='rejected').length;
      if (count >= Number(scrim?.slots || 12)) return setNotice('All slots are full for this scrim.');
      setTeams(old=>[...old,{id:`demo-${Date.now()}`,...teamForm,players,scrim_id:teamForm.scrim_id,payment_status:'pending',registration_status:'pending',created_at:new Date().toISOString()}]);
      setNotice('Demo registration added to this browser only. Connect Supabase for shared registrations.');
      setTab('Scrims'); return;
    }
    if (!user) return setNotice('Please sign in before registering a team.');
    const {data:existing} = await supabase.from('teams').select('id').eq('scrim_id',teamForm.scrim_id).ilike('team_name',teamForm.team_name).maybeSingle();
    if (existing) return setNotice('That team name is already registered for this scrim.');
    const {data:inserted,error} = await supabase.from('teams').insert({scrim_id:teamForm.scrim_id,team_name:teamForm.team_name.trim(),captain_ign:teamForm.captain_ign.trim(),players,owner_id:user.id,registration_status:'pending',payment_status:'pending'}).select().single();
    if (error) return setNotice(error.message);
    const {error:payError} = await supabase.from('payments').insert({team_id:inserted.id,method:teamForm.payment_method,reference:teamForm.payment_reference || null,amount:Number(scrims.find(s=>s.id===teamForm.scrim_id)?.entry_fee || 0),status:'pending',user_id:user.id});
    if (payError) setNotice('Team registered, but payment record needs admin review: '+payError.message);
    else setNotice('Registration submitted. Admin will review your team and payment.');
    await loadData(); setTab('Scrims');
  }
  async function createScrim(e) {
    e.preventDefault();
    if (!isAdmin) return setNotice('Admin access required.');
    if (!isSupabaseConfigured) {
      setScrims(old=>[{id:`demo-${Date.now()}`, ...scrimForm, entry_fee:Number(scrimForm.entry_fee),prize_pool:Number(scrimForm.prize_pool),slots:12,status:'open'},...old]);
      setNotice('Demo scrim created in this browser only.'); return;
    }
    const {error} = await supabase.from('scrims').insert({...scrimForm,entry_fee:Number(scrimForm.entry_fee),prize_pool:Number(scrimForm.prize_pool),slots:12,status:'open',created_by:user.id});
    setNotice(error ? error.message : 'Scrim created.');
    await loadData();
  }
  async function saveResult(e) {
    e.preventDefault();
    if (!isAdmin) return setNotice('Admin access required.');
    const row = {...resultForm,match_no:Number(resultForm.match_no),placement:Number(resultForm.placement),kills:Number(resultForm.kills),placement_points:placementPoints[Number(resultForm.placement)] ?? 0};
    if (!row.team_name.trim()) return setNotice('Enter a team name.');
    if (!isSupabaseConfigured) setResults(old=>[...old,row]);
    else {
      const {error} = await supabase.from('match_results').insert({...row,created_by:user.id});
      if (error) return setNotice(error.message);
      await loadData();
    }
    setNotice('Result saved and leaderboard recalculated.');
  }
  async function reviewTeam(teamId, status) {
    if (!isAdmin) return;
    if (!isSupabaseConfigured) {
      setTeams(old=>old.map(t=>t.id===teamId?{...t,registration_status:status}:t));
    } else {
      const {error} = await supabase.from('teams').update({registration_status:status}).eq('id',teamId);
      if (error) return setNotice(error.message);
      await loadData();
    }
    setNotice(`Team ${status}.`);
  }
  async function reviewPayment(paymentId, status, teamId) {
    if (!isAdmin) return;
    if (!isSupabaseConfigured) {
      setTeams(old=>old.map(t=>t.id===teamId?{...t,payment_status:status}:t));
      setPayments(old=>old.map(p=>p.id===paymentId?{...p,status}:p));
    } else {
      const {error} = await supabase.from('payments').update({status,reviewed_by:user.id,reviewed_at:new Date().toISOString()}).eq('id',paymentId);
      if (error) return setNotice(error.message);
      if (teamId) await supabase.from('teams').update({payment_status:status}).eq('id',teamId);
      await loadData();
    }
    setNotice(`Payment marked ${status}.`);
  }

  const activeScrims = scrims.filter(s=>s.status!=='closed');
  const teamCount = teams.filter(t=>t.registration_status!=='rejected').length;
  const getScrim = id => scrims.find(s=>s.id===id);
  const approvedTeams = teams.filter(t=>t.registration_status==='approved');

  return <div className="app-shell">
    <div className="topline"><span><span className="live-dot"></span> NEPAL ESPORTS • FREE FIRE SCRIMS</span><span>🇳🇵 NPT (UTC+5:45)</span></div>
    <header className="header">
      <button className="brand" onClick={()=>setTab('Home')} aria-label="KOF Scrims Zone home"><span className="brand-mark"><Crown size={24}/></span><span><strong>KOF <b>SCRIMS ZONE</b></strong><small>REGISTER. COMPETE. DOMINATE.</small></span></button>
      <nav className="desktop-nav">{nav.map(n=><button key={n} className={tab===n?'active':''} onClick={()=>setTab(n)}>{n}</button>)}</nav>
      <div className="header-actions">{user ? <button className="outline-btn" onClick={signOut}><LogOut size={16}/> Sign out</button> : <button className="gold-btn small" onClick={()=>setTab('Profile')}><LogIn size={16}/> Sign in</button>}
      <button className="menu-btn" onClick={()=>setMobileMenu(!mobileMenu)} aria-label="Toggle menu">{mobileMenu?<X/>:<Menu/>}</button></div>
    </header>
    {mobileMenu && <nav className="mobile-nav">{nav.map(n=><button key={n} onClick={()=>{setTab(n);setMobileMenu(false)}}>{n}</button>)}</nav>}
    {notice && <div className="notice"><AlertTriangle size={16}/><span>{notice}</span><button onClick={()=>setNotice('')} aria-label="Dismiss notice"><X size={15}/></button></div>}
    {loading && <div className="loading"><RefreshCw className="spin" size={16}/> Loading tournament data…</div>}

    {tab==='Home' && <>
      <section className="hero">
        <div className="hero-content"><div className="eyebrow"><span className="eyebrow-line"></span> NEPAL'S BATTLE STARTS HERE</div><h1>YOUR SQUAD.<br/><em>YOUR LEGACY.</em></h1><p>Join the arena, prove your skills, and climb the KOF leaderboard. Your next Booyah starts here.</p>
          <div className="hero-buttons"><button className="gold-btn" onClick={()=>setTab('Scrims')}>Explore scrims <ChevronRight size={18}/></button><button className="outline-btn" onClick={()=>setTab('Register')}>Register team <Users size={17}/></button></div>
          <div className="hero-stats"><div><strong>{scrims.length.toString().padStart(2,'0')}</strong><span>SCRIMS</span></div><div><strong>12</strong><span>TEAMS / LOBBY</span></div><div><strong>🇳🇵</strong><span>NEPAL REGION</span></div></div>
        </div><div className="hero-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="hero-emblem"><Crown size={78}/><span>KOF</span><small>SCRIMS ZONE</small></div><div className="art-tag tag-top">SEASON 01 <span>•</span> OPEN</div><div className="art-tag tag-bottom"><Swords size={16}/> BATTLE FOR GLORY</div></div>
      </section>
      <section className="section">
        <div className="section-heading"><div><span className="section-kicker">DON'T MISS OUT</span><h2>Featured <em>scrims</em></h2></div><button className="text-btn" onClick={()=>setTab('Scrims')}>View all <ChevronRight size={16}/></button></div>
        <div className="scrim-grid">{activeScrims.slice(0,3).map(s=><ScrimCard key={s.id} scrim={s} registered={teams.filter(t=>t.scrim_id===s.id&&t.registration_status!=='rejected').length} onRegister={()=>{setTeamForm(f=>({...f,scrim_id:s.id}));setTab('Register')}}/>)}</div>
      </section>
      <section className="feature-strip"><Feature icon={<Trophy/>} title="Live leaderboard" text="Points calculated from placements and eliminations."/><Feature icon={<ShieldCheck/>} title="Fair play first" text="Team registrations and payments reviewed by admins."/><Feature icon={<Wallet/>} title="NPR payments" text="Track eSewa payment references in one place."/></section>
    </>}

    {tab==='Scrims' && <main className="page"><PageTitle kicker="FIND YOUR NEXT MATCH" title="Available scrims" subtitle="Choose a lobby, register your squad, and compete for the prize pool."/><div className="scrim-grid">{activeScrims.length?activeScrims.map(s=><ScrimCard key={s.id} scrim={s} registered={teams.filter(t=>t.scrim_id===s.id&&t.registration_status!=='rejected').length} onRegister={()=>{setTeamForm(f=>({...f,scrim_id:s.id}));setTab('Register')}}/>):<Empty text="No open scrims right now. Check back soon."/>}</div></main>}

    {tab==='Leaderboard' && <main className="page"><PageTitle kicker="EVERY ELIMINATION COUNTS" title="Point table" subtitle="Rankings update automatically from saved match results."/><div className="panel"><div className="panel-head"><h3><Trophy size={18}/> Overall standings</h3><span className="pill">LIVE TABLE</span></div><div className="table-wrap"><table><thead><tr><th>RANK</th><th>TEAM</th><th>MATCHES</th><th>BOOYAH</th><th>PLACEMENT PTS</th><th>KILLS</th><th>TOTAL</th></tr></thead><tbody>{standings.map((r,i)=><tr key={r.team_name}><td><span className={`rank rank-${i+1}`}>{String(i+1).padStart(2,'0')}</span></td><td className="team-cell">{r.team_name}</td><td>{r.matches}</td><td>{r.booyahs}</td><td>{r.placement_points}</td><td>{r.kills}</td><td className="total-cell">{r.total}</td></tr>)}</tbody></table>{!standings.length&&<Empty text="No match results yet. The table will populate after the admin posts results."/>}</div><p className="muted tiny">Default placement scoring: 1st 12, 2nd 9, 3rd 8, 4th 7, 5th 6, 6th 5, 7th 4, 8th 3, 9th 2, 10th 1; each kill adds 1 point. Admins can change this in src/App.jsx.</p></div></main>}

    {tab==='Register' && <main className="page"><PageTitle kicker="CLAIM YOUR SLOT" title="Register your team" subtitle="Enter accurate team details. Your registration and payment stay pending until reviewed."/><div className="form-layout"><form className="panel form-panel" onSubmit={registerTeam}><h3><Users size={19}/> Team details</h3><label>Choose scrim<select value={teamForm.scrim_id} onChange={e=>setTeamForm({...teamForm,scrim_id:e.target.value})}>{activeScrims.map(s=><option key={s.id} value={s.id}>{s.title} — {money(s.entry_fee)}</option>)}</select></label><label>Team name<input required maxLength="40" value={teamForm.team_name} onChange={e=>setTeamForm({...teamForm,team_name:e.target.value})} placeholder="e.g. KOF ESPORTS"/></label><label>Captain IGN<input required maxLength="32" value={teamForm.captain_ign} onChange={e=>setTeamForm({...teamForm,captain_ign:e.target.value})} placeholder="In-game name"/></label><div className="two-col"><label>Player 2 IGN<input value={teamForm.player2} onChange={e=>setTeamForm({...teamForm,player2:e.target.value})} placeholder="Optional"/></label><label>Player 3 IGN<input value={teamForm.player3} onChange={e=>setTeamForm({...teamForm,player3:e.target.value})} placeholder="Optional"/></label></div><label>Player 4 IGN<input value={teamForm.player4} onChange={e=>setTeamForm({...teamForm,player4:e.target.value})} placeholder="Optional"/></label><div className="form-divider"></div><h3><Wallet size={18}/> Payment tracking</h3><label>Payment method<select value={teamForm.payment_method} onChange={e=>setTeamForm({...teamForm,payment_method:e.target.value})}><option>eSewa</option><option>Bank transfer</option><option>Other</option></select></label><label>Transaction reference / note<input value={teamForm.payment_reference} onChange={e=>setTeamForm({...teamForm,payment_reference:e.target.value})} placeholder="Enter reference if already paid"/></label><div className="payment-note"><AlertTriangle size={16}/><span>Submitting a reference does not confirm payment. Admin verification is required. Ask the organizer for the official payment details.</span></div><button className="gold-btn full" type="submit">Submit registration <ChevronRight size={17}/></button>{!user&&isSupabaseConfigured&&<p className="muted tiny">You must sign in before submitting a live registration.</p>}</form><aside className="panel side-panel"><span className="section-kicker">REGISTRATION CHECKLIST</span><h3>Before you submit</h3><ul className="check-list"><li><CheckCircle2/> Correct team name and captain IGN</li><li><CheckCircle2/> All player names are accurate</li><li><CheckCircle2/> Payment reference is correct</li><li><CheckCircle2/> Wait for admin approval</li></ul><div className="slot-widget"><div><span>LOBBY CAPACITY</span><strong>{teamCount} / {scrims.reduce((n,s)=>n+Number(s.slots||12),0)} <small>registrations</small></strong></div><div className="progress"><span style={{width:`${Math.min(100,teamCount/Math.max(1,scrims.reduce((n,s)=>n+Number(s.slots||12),0))*100)}%`}}/></div><p className="muted tiny">Each scrim has a 12-team capacity by default.</p></div></aside></div></main>}

    {tab==='Payments' && <main className="page"><PageTitle kicker="PAYMENT RECORDS" title="Payment tracking" subtitle="Track submitted references and admin review status."/><div className="panel"><div className="panel-head"><h3><Wallet size={18}/> My payments</h3><span className="pill">NPR</span></div>{!user&&isSupabaseConfigured?<Empty text="Sign in to view your payment records."/>:<div className="table-wrap"><table><thead><tr><th>TEAM / ID</th><th>METHOD</th><th>AMOUNT</th><th>REFERENCE</th><th>STATUS</th></tr></thead><tbody>{(isSupabaseConfigured?payments.filter(p=>p.user_id===user?.id):payments).map(p=><tr key={p.id}><td>{teams.find(t=>t.id===p.team_id)?.team_name||p.team_id||'Demo payment'}</td><td>{p.method}</td><td>{money(p.amount)}</td><td>{p.reference||'—'}</td><td><Status value={p.status}/></td></tr>)}</tbody></table>{!(isSupabaseConfigured?payments.filter(p=>p.user_id===user?.id):payments).length&&<Empty text="No payment records to show yet. Submit a team registration first."/>}</div>}</div><div className="info-banner"><ShieldCheck/><div><strong>Payment safety</strong><p>Never share your eSewa password, PIN, or OTP. This starter tracks payment references; direct gateway verification must be configured separately with official eSewa credentials.</p></div></div></main>}

    {tab==='Profile' && <main className="page"><PageTitle kicker="PLAYER ACCOUNT" title={user?'Your profile':'Join KOF Scrims Zone'} subtitle={user?'Your account and registered teams.':'Create an account to register teams and track payments.'}/><div className="profile-layout"><div className="panel auth-panel"><div className="auth-icon"><UserRound size={26}/></div>{user?<><h3>Welcome back</h3><p className="muted">{user.email}</p><div className="profile-row"><span>Display name</span><strong>{profile?.display_name||user.user_metadata?.display_name||'Player'}</strong></div><div className="profile-row"><span>Account role</span><strong>{isAdmin?'Admin':'Player'}</strong></div><button className="outline-btn full" onClick={signOut}><LogOut size={16}/> Sign out</button></>:<><div className="auth-toggle"><button className={authMode==='signin'?'selected':''} onClick={()=>setAuthMode('signin')}>Sign in</button><button className={authMode==='signup'?'selected':''} onClick={()=>setAuthMode('signup')}>Create account</button></div><form onSubmit={signIn} className="stack-form">{authMode==='signup'&&<label>Display name<input required value={displayName} onChange={e=>setDisplayName(e.target.value)} placeholder="Your name / IGN"/></label>}<label>Email address<input type="email" required value={authEmail} onChange={e=>setAuthEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input type="password" minLength="6" required value={authPassword} onChange={e=>setAuthPassword(e.target.value)} placeholder="At least 6 characters"/></label><button className="gold-btn full" type="submit">{authMode==='signin'?'Sign in':'Create account'} <ChevronRight size={17}/></button></form>{!isSupabaseConfigured&&<p className="muted tiny">Demo mode: configure Supabase to enable secure accounts.</p>}</>}</div><div className="panel"><h3><ClipboardList size={18}/> My registrations</h3>{!user&&isSupabaseConfigured?<Empty text="Sign in to see registrations."/>:teams.filter(t=>!isSupabaseConfigured||t.owner_id===user?.id).map(t=><div className="registration-row" key={t.id}><div><strong>{t.team_name}</strong><small>{getScrim(t.scrim_id)?.title||'Scrim'} · {t.captain_ign}</small></div><div className="status-stack"><Status value={t.registration_status}/><Status value={t.payment_status}/></div></div>)}{(isSupabaseConfigured?teams.filter(t=>t.owner_id===user?.id):teams).length===0&&<Empty text="No registrations yet."/>}</div></div></main>}

    {tab==='Admin' && <main className="page"><PageTitle kicker="ORGANIZER CONTROL ROOM" title="Admin dashboard" subtitle="Manage scrims, review registrations, confirm payments, and post results."/>{!isAdmin?<div className="panel restricted"><ShieldCheck size={32}/><h3>Admin access required</h3><p className="muted">Sign in with an account whose Supabase profile role is set to <code>admin</code>. Never expose a service-role key in the browser.</p></div>:<div className="admin-grid"><form className="panel form-panel" onSubmit={createScrim}><h3><Plus size={18}/> Create scrim</h3><label>Scrim title<input required value={scrimForm.title} onChange={e=>setScrimForm({...scrimForm,title:e.target.value})}/></label><label>Date<input type="date" value={scrimForm.date} onChange={e=>setScrimForm({...scrimForm,date:e.target.value})}/></label><label>Time<input required value={scrimForm.time} onChange={e=>setScrimForm({...scrimForm,time:e.target.value})}/></label><div className="two-col"><label>Entry fee (NPR)<input type="number" min="0" value={scrimForm.entry_fee} onChange={e=>setScrimForm({...scrimForm,entry_fee:e.target.value})}/></label><label>Prize pool (NPR)<input type="number" min="0" value={scrimForm.prize_pool} onChange={e=>setScrimForm({...scrimForm,prize_pool:e.target.value})}/></label></div><label>Maps<input value={scrimForm.maps} onChange={e=>setScrimForm({...scrimForm,maps:e.target.value})}/></label><button className="gold-btn full">Publish scrim</button></form><form className="panel form-panel" onSubmit={saveResult}><h3><Trophy size={18}/> Post match result</h3><label>Scrim<select value={resultForm.scrim_id} onChange={e=>setResultForm({...resultForm,scrim_id:e.target.value})}>{scrims.map(s=><option key={s.id} value={s.id}>{s.title}</option>)}</select></label><label>Team name<input required value={resultForm.team_name} onChange={e=>setResultForm({...resultForm,team_name:e.target.value})}/></label><div className="two-col"><label>Match #<input type="number" min="1" value={resultForm.match_no} onChange={e=>setResultForm({...resultForm,match_no:e.target.value})}/></label><label>Placement<select value={resultForm.placement} onChange={e=>setResultForm({...resultForm,placement:e.target.value})}>{Array.from({length:12},(_,i)=><option key={i+1} value={i+1}>{i+1}{['st','nd','rd'][i]||'th'}</option>)}</select></label></div><label>Kills<input type="number" min="0" value={resultForm.kills} onChange={e=>setResultForm({...resultForm,kills:e.target.value})}/></label><div className="payment-note"><Trophy size={16}/><span>Placement points: {placementPoints[Number(resultForm.placement)] ?? 0} + {Number(resultForm.kills)||0} kill points = {(placementPoints[Number(resultForm.placement)] ?? 0)+(Number(resultForm.kills)||0)} total points for this match.</span></div><button className="gold-btn full">Save result</button></form><div className="panel admin-wide"><div className="panel-head"><h3><Users size={18}/> Registration review</h3><span className="pill">{teams.length} TEAMS</span></div>{teams.map(t=><div className="admin-row" key={t.id}><div><strong>{t.team_name}</strong><small>{getScrim(t.scrim_id)?.title||'Scrim'} · Captain: {t.captain_ign}</small></div><Status value={t.registration_status}/><div className="row-actions"><button className="mini-btn approve" onClick={()=>reviewTeam(t.id,'approved')}>Approve</button><button className="mini-btn reject" onClick={()=>reviewTeam(t.id,'rejected')}>Reject</button></div></div>)}{!teams.length&&<Empty text="No registrations yet."/>}</div><div className="panel admin-wide"><div className="panel-head"><h3><Wallet size={18}/> Payment review</h3><span className="pill">{payments.length} RECORDS</span></div>{payments.map(p=><div className="admin-row" key={p.id}><div><strong>{teams.find(t=>t.id===p.team_id)?.team_name||'Team payment'}</strong><small>{p.method} · {money(p.amount)} · Ref: {p.reference||'not provided'}</small></div><Status value={p.status}/><div className="row-actions"><button className="mini-btn approve" onClick={()=>reviewPayment(p.id,'paid',p.team_id)}>Mark paid</button><button className="mini-btn reject" onClick={()=>reviewPayment(p.id,'rejected',p.team_id)}>Reject</button></div></div>)}{!payments.length&&<Empty text="No payment records yet."/>}</div></div>}</main>}

    <footer className="footer"><div className="footer-brand"><Crown/><span>KOF <b>SCRIMS ZONE</b></span></div><p>Built for the next generation of Nepal esports.</p><div className="footer-bottom"><span>© {new Date().getFullYear()} KOF SCRIMS ZONE</span><span>FAIR PLAY • RESPECT • BOOYAH</span></div></footer>
  </div>;
}

function PageTitle({kicker,title,subtitle}) { return <div className="page-title"><span className="section-kicker">{kicker}</span><h1>{title.split(' ').slice(0,-1).join(' ')} <em>{title.split(' ').slice(-1)}</em></h1><p>{subtitle}</p></div>; }
function ScrimCard({scrim,registered,onRegister}) {
  const full = registered >= Number(scrim.slots||12);
  return <article className="scrim-card"><div className="scrim-card-top"><span className="game-tag"><Swords size={13}/> FREE FIRE</span><Status value={full?'full':scrim.status||'open'}/></div><div className="scrim-art"><div className="scrim-art-ring"></div><Crown size={48}/><span>KOF</span></div><div className="scrim-card-body"><h3>{scrim.title}</h3><div className="scrim-meta"><span><Clock3 size={14}/>{scrim.time||'Time TBA'}</span><span><ClipboardList size={14}/>{dateText(scrim.date)}</span></div><div className="scrim-details"><div><small>ENTRY FEE</small><strong>{money(scrim.entry_fee)}</strong></div><div><small>PRIZE POOL</small><strong className="gold-text">{money(scrim.prize_pool)}</strong></div></div><div className="capacity"><div><span>{registered}/{scrim.slots||12} teams</span><span>{full?'FULL':`${Math.max(0,(scrim.slots||12)-registered)} slots left`}</span></div><div className="progress"><span style={{width:`${Math.min(100,registered/Math.max(1,scrim.slots||12)*100)}%`}}/></div></div><div className="maps">MAPS <b>{scrim.maps||'B / P / K / N'}</b></div><button className="gold-btn full" disabled={full||scrim.status==='closed'} onClick={onRegister}>{full?'Lobby full':'Register squad'} <ChevronRight size={17}/></button></div></article>;
}
function Status({value}) {
  const v=String(value||'pending').toLowerCase();
  const cls=['paid','approved','open'].includes(v)?'good':['rejected','closed','full'].includes(v)?'bad':v==='booked'?'booked':'pending';
  const label={approved:'APPROVED',paid:'PAID',open:'OPEN',pending:'PENDING',rejected:'REJECTED',closed:'CLOSED',full:'FULL',booked:'BOOKED'}[v]||v.toUpperCase();
  return <span className={`status ${cls}`}><span/> {label}</span>;
}
function PageTitleDummy(){}
function Empty({text}) { return <div className="empty"><div className="empty-icon"><ClipboardList size={22}/></div><p>{text}</p></div>; }
function Feature({icon,title,text}) { return <div className="feature"><div className="feature-icon">{icon}</div><div><h3>{title}</h3><p>{text}</p></div></div>; }
