import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;

// The site can run in demo mode before Supabase is configured.
// For a public launch, configure Supabase and apply supabase/schema.sql.
export const isSupabaseConfigured = Boolean(url && key && !url.includes('YOUR-PROJECT') && !key.includes('YOUR_SUPABASE'));
export const supabase = isSupabaseConfigured ? createClient(url, key) : null;
